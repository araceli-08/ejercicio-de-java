/**
 * 
 */
/**
 * @author Jhon
 *
 */
module sercuenciales {
}