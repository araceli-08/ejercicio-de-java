package sercuenciales;

	import java.util.Scanner;
	public class porcentajemujereshombres {

		 public static void main(String[] args) {
			   
		        Scanner t=new Scanner(System.in);
		       
		        int numtotal,numhombres,nummujeres,porcmujeres,porchombres;
		       
		        System.out.println("Ingrese el numero de hombres");
		        numhombres=t.nextInt();
		   
		        System.out.println("Ingrese el numero de mujeres");
		        nummujeres=t.nextInt();
		       
		      
		        numtotal=numhombres+nummujeres;
		       
		        porchombres=(100*numhombres)/numtotal;
		        porcmujeres=(100*nummujeres)/numtotal;
		       
		       
		       
		        System.out.println("El total de hombres y mujeres son : "+numtotal);
		        System.out.println(""+porchombres+"% de hombres");
		        System.out.println(""+porcmujeres+"% de mujeres");

		    }
		   

		}


